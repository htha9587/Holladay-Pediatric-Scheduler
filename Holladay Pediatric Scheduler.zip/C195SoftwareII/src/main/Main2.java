package main;

public class Main2
{

    public static void main(String[] args)
    {
        Main.main(args);
    }
}
